@echo off
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
echo Run install.bat first.
pause
exit /b 1
)
.venv\Scripts\python.exe validation_app.py
if errorlevel 1 pause
